#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#define BUFFER_SIZE 31
#define READ_END 0
#define WRITE_END 1
char Change(char Ah){
    if(Ah>='a' && Ah<='z'){
				Ah= Ah-32;
			}
			else if(Ah>='A' && Ah<='Z'){
				Ah = Ah+32;
			}
            return Ah;
}
int main(){
	//创建两个管道
	int fd1[2],fd2[2];
	//信息传递数组
	char write1[BUFFER_SIZE];
	char read1[BUFFER_SIZE];
	char write2[BUFFER_SIZE];
	char read2[BUFFER_SIZE];
	//错误判断
	if (pipe(fd1) == -1 || pipe(fd2) == -1) {
		printf("创建管道失败\n");
		return -1;
	}
	//数据获取
	scanf("%[^\n]",&write1);
	pid_t pid= fork();
	//错误判断
	if (pid < 0) { /* error occurred */
		printf("创建线程失败\n");
		return -1;
	}
	//父进程
	if (pid > 0) {
		close(fd1[READ_END]);
		printf("父线程发送子线程消息: %s\n", write1);
        //向管道1里写数据
		write(fd1[WRITE_END], write1, strlen(write1)+1);
        //关闭管道1和2的写内容
		close(fd1[WRITE_END]);
		close(fd2[WRITE_END]);
        //读取管道2里子进程写进来的内容
		read(fd2[READ_END], read1, BUFFER_SIZE);
		printf("父线程收到子线程消息: %s\n", read1);
		close(fd2[READ_END]);
	}
	//子进程
	else {
		close(fd1[WRITE_END]);
		read(fd1[READ_END], read2, BUFFER_SIZE);
		printf("子线程收到父线程消息: %s\n", read2);
		close(fd1[READ_END]);
		int i=0;
		//大小写转化
		for(i = 0; i < strlen(read2); i++){
            read2[i]=Change(read2[i]);
		}
		strcpy(write2,read2);
		close(fd2[READ_END]);
		printf("子线程发送消息给父线程: %s\n", write2);
		write(fd2[WRITE_END], write2, strlen(write2)+1);
		close(fd2[WRITE_END]);
	}
	return 0;
}

