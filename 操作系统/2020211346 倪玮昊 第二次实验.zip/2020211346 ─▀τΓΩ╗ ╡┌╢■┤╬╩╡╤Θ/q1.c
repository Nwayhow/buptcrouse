#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <wait.h>
int main(int argc,char* argv[]){
	int number=0;
	if(argv[1]!='\0'){
		number = atoi(argv[1]);//命令行第二个输入
	}
	pid_t f=fork();
	if(f<0){
		printf("创建子进程出错!");
	}//没有顺利创建子进程
	//子线程的情况
	else if(f==0){
		printf("进入子进程ID是: %d\n", getpid());
		printf("数字序列是: %d ",number);
		//序列的生成
		while(number!=1){
			if(number%2==0){
				number=number/2;
				printf("%d ",number);
			}
			else{
				number=3*number+1;
				printf("%d ",number);
			}
		}
		printf("\n");
	}
	//父线程的情况
	else{
		wait(NULL);
		printf("父进程进程ID是: %d\n", getpid());
		
	}
	return 0;
}
