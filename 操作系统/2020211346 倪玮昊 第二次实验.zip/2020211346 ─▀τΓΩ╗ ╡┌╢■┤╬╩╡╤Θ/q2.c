#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <unistd.h>
#include <wait.h>
int main(int argc,char* argv[]){
	const int SIZE=4090;
	void *ptr1;
	int number=0;
    	const char *name = "q2";
	//数据的获取
	if(argv[1]!='\0'){
		number = atoi(argv[1]);
	}
	pid_t fpid;
	fpid=fork();
	//错误判断
	if(fpid<0){
		printf("创建子进程出错\n!");
	}
	//子线程
	else if(fpid==0){
		printf("子进程ID是: %d\n对应序列开始字符为: %d\n",getpid(),number);
		//创立公共空间
		int shm_fd1 = shm_open( name , O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);

		//错误判断
		if(shm_fd1 < 0){
			printf("打开失败!\n");
			return -1;
		}
		else{
            ftruncate(shm_fd1, SIZE);
            char num[10]={0};
			sprintf(num,"%d",number);
            ptr1 = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, shm_fd1, 0);
            sprintf(ptr1,"%s", num);
			ptr1 += strlen(num);
            sprintf(ptr1," ");
			ptr1 += strlen(" ");
			while(number!=1){
				if(number%2==0){
					number/=2;
				}
				else{
					number = 3*number+1;
				}
				sprintf(num,"%d",number);
			 sprintf(ptr1,"%s", num);
			ptr1 += strlen(num);
            sprintf(ptr1," ");
			ptr1 += strlen(" ");
			}
			printf("序列输入完毕\n");
		}
	}
	//父线程
	else{
		wait(NULL);
		printf("父进程进程ID是: %d\n对应序列如下: \n", getpid());
		void *ptr2;
		int shm_fd2 = shm_open( name , O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
		if(shm_fd2 < 0){
			printf("打开失败!\n");
			return -1;
		}
		else{
			ptr2 = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, shm_fd2, 0);
			printf("%s\n",(char *)ptr2);
			shm_unlink(name);
		}
	}
	return 0;
}
