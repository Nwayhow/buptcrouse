#include<iostream>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<pthread.h>
#include<fstream>
#include<vector>
#include<semaphore.h>
#include<unistd.h>
using namespace std;
typedef struct order
{
char rw; //读写进程标志
int spendtime; //读写时间
}order;
vector<order>orders; //命令集合
int orderNum=20;
int shared_data[20]; //共享数据
int read_count; //读者数量
int count=0;
int write_count; //写者数量
sem_t wp_wrt; //互斥变量,控制对缓冲区的访问，初始化为 1
sem_t cs_read; //互斥变量，表示读者排队信号，初始化为 1
sem_t mutex_w; //互斥变量，控制 write_count 的互斥访问，初始化为 1
sem_t mutex_r; //互斥变量，控制 read_count 的互斥访问，初始化为 1

void *writer(void *param)
{
sem_wait(&mutex_w); //互斥访问 write_count
write_count++;
if(write_count == 1) //如果是第一个写进程，申请获取读进程排队权限
sem_wait(&cs_read);
sem_post(&mutex_w);
sem_wait(&wp_wrt); //申请缓冲区访问权限
int myid =*(int*)param;
cout<<"写进程进入临界区"<<endl;
cout<<"写进程向临界区写入ID 耗时:"<<orders[myid].spendtime<<endl;
cout<<"W "<<myid<<endl;
shared_data[count]=myid;
count++;
sleep(orders[myid].spendtime);
cout<<"写进程写入完毕"<<endl;
cout<<"写进程释放占有临界区"<<endl;
sem_post(&wp_wrt);
sem_wait(&mutex_w);
write_count--;
if(write_count == 0)
sem_post(&cs_read); //如果是最后一个写进程，释放读进程排队权限，允许其排队访
sem_post(&mutex_w);
}

void *reader(void *param) 
{
sem_wait(&cs_read); //申请排队权限
sem_wait(&mutex_r); //互斥访问 read_count
read_count++;
 if(read_count == 1) //如果是第一个读者，申请访问权限
sem_wait(&wp_wrt);
sem_post(&mutex_r);
sem_post(&cs_read); //释放排队权限
int myid=*(int*)param;
cout<<"读进程开始读取内容 耗时:"<<orders[myid].spendtime<<endl;
cout<<"读进程开始读取临界区的内容"<<endl;
cout<<"R "<<myid<<endl;
if(count==0)
{
  cout<<"shared data is empty\n";
}
for(int i=0;i<count;i++)
{
cout << shared_data[i] << " ";
}
cout<<endl;
sleep(orders[myid].spendtime);
cout<<"读进程内容读取完毕"<<endl;
cout<<"读进程释放占有临界区"<<endl;
sem_wait(&mutex_r);
read_count--;
if(read_count == 0) //如果是最后一个读者，释放缓冲区访问权限
sem_post(&wp_wrt);
sem_post(&mutex_r);
}

int main()
{
  freopen("output.txt", "w", stdout);
  sem_init(&wp_wrt,0,1);
  sem_init(&mutex_r,0,1);
  sem_init(&mutex_w,0,1);
  sem_init(&cs_read,0,1);
  ifstream file("data.txt");
  order t;
  for(int i = 0; i < orderNum; i++) {
    file >> t.rw >> t.spendtime;
    orders.push_back(t);
  }
  pthread_t *p = (pthread_t *)malloc(orderNum * sizeof(pthread_t));
  int *p_id = (int *)malloc(orderNum * sizeof(int));
  for(int i = 0; i < orderNum; i++)
  {
    if(orders[i].rw == 'R') //创建读进程
    {
        p_id[i] = i + 1;
        pthread_create(&p[i], NULL, reader, &p_id[i]);
        cout<<"新创建了一个读进程"<<endl;
    }
    else //创建写进程
    {
        p_id[i] = i + 1;
        pthread_create(&p[i], NULL, writer, &p_id[i]);
        cout<<"新创建了一个写进程"<<endl;
    }
  }
  for(int i = 0; i < orderNum; i++)
  {
     pthread_join(p[i], NULL);
  }
}
