#include<iostream>
#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<pthread.h>
#include<fstream>
#include<vector>
#include<semaphore.h>

#include<unistd.h>
using namespace std;
typedef struct order
{
char rw; //读写进程标志
int spendtime; //读写时间
}order;
vector<order>orders; //命令集合
int orderNum=20;
int shared_data[20]; //共享数据
int read_count; //读者数量
sem_t rp_wrt; //互斥变量，用于控制对缓冲区的访问，初始化为 1
sem_t mutex;
int count=0;


void *reader(void *param) {
sem_wait(&mutex); //互斥访问 read_count
read_count++;
if(read_count == 1) //如果是第一个读进程，申请获取访问权限
sem_wait(&rp_wrt);
sem_post(&mutex);
cout<<"读进程进入临界区"<<endl;
int myid=*(int*)param;
cout<<"读进程开始读取内容 耗时:"<<orders[myid].spendtime<<endl;
//读取进程的名字
cout<<"目前的进程是R "<<myid<<endl;
if(count==0)
{
  cout<<"共享数据为空"<<endl;
}
for(int i=0;i<count;i++)
{
cout << shared_data[i] << " ";
}
sleep(orders[myid].spendtime);
cout<<endl;
cout<<"内容读取完毕"<<endl;
cout<<"读进程释放占有临界区"<<endl;
sem_wait(&mutex);

read_count--;

if(read_count == 0) //如果是最后一个读进程，释放访问权限
sem_post(&rp_wrt);
sem_post(&mutex);
}

void *writer (void *param) {
sem_wait(&rp_wrt); //等待访问权限
int myid =*(int*)param;
cout<<"写进程进入临界区"<<endl;
cout<<"写进程向临界区写入ID 耗时:"<<orders[myid].spendtime<<endl;

cout<<"W "<<myid<<endl;
shared_data[count]=myid;
count++;
sleep(orders[myid].spendtime);
cout<<"写进程写入完毕"<<endl;
cout<<"写进程释放临界区互斥"<<endl;
sem_post(&rp_wrt); //释放访问权限
}

int main()
{
  freopen("output.txt", "w", stdout);
  sem_init(&rp_wrt,0,1);
  sem_init(&mutex,0,1);
  ifstream file("data.txt");
  order t;
  for(int i = 0; i < orderNum; i++) {
    file >> t.rw >> t.spendtime;
    orders.push_back(t);
  }
  pthread_t *p = (pthread_t *)malloc(orderNum * sizeof(pthread_t));//构造动态数组
  int *p_id = (int *)malloc(orderNum * sizeof(int));
  for(int i = 0; i < orderNum; i++)
  {
    if(orders[i].rw == 'R') //创建读进程
    {
        p_id[i] = i + 1;
        pthread_create(&p[i], NULL, reader, &p_id[i]);
        cout<<"新创建了一个读进程"<<endl;
    }
    else //创建写进程
    {
        p_id[i] = i + 1;
        pthread_create(&p[i], NULL, writer, &p_id[i]);
        cout<<"新创建了一个写进程"<<endl;
    }
  }
  for(int i = 0; i < orderNum; i++)
  {
     pthread_join(p[i], NULL);
  }
}