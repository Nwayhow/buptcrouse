package work;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

class cen extends JPanel {

    JFrame f = new JFrame();// 创建窗体
    Container c;// 容器
    static JTextArea ta;
    static JTextArea tb;
    static Socket socket;
    DataOutputStream os;
    JLabel stu;
    JTextField tf ;
    JTextField tf2;
    public void way2() throws IOException {
        // Content(包含)，pane（窗格）
        c = f.getContentPane();// 容器c嵌入窗体f中
        c.setLayout(new FlowLayout());// 布局，流布局，flow（流动）
        f.setTitle("登录界面");
        f.setBounds(600, 150, 400, 400);
        f.setLocationRelativeTo(null);
        ImageIcon imgicon = new ImageIcon("2.jpg");//图片插入，更改图片路径，需要注意后缀

        JLabel imgjla = new JLabel(imgicon);
        Dimension dim = new Dimension(360,203);
        imgjla.setPreferredSize(dim);


        ta = new JTextArea(5, 40);
        tb = new JTextArea(10, 40);
        JLabel den=new JLabel();
        JLabel zhu=new JLabel();
        stu=new JLabel();
        den.setText("账号");
        zhu.setText("密码");
        stu.setText("     未登录");
        //聊天记录输入区
        ta.setEditable(false);
        tb.setEditable(false);
       tf = new JTextField(36);
       tf2 = new JTextField(36);
        tf.requestFocus();//guang biao
        JButton jb = new JButton("登录");
        JButton jb1 = new JButton("注册");
        c.add(imgjla);
        c.add(den);
        c.add(tf2, BorderLayout.SOUTH);
        c.add(zhu);
        c.add(tf, BorderLayout.SOUTH);
        c.add(jb);
        c.add(jb1);
        c.add(stu);
        f.setResizable(false);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jb.addActionListener(new ActionListener() {//登录操作
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = tf2.getText();
                String password = tf.getText();
                try {
                    client();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                new Thread(new Receive()).start();
                if(name==null || password==null){
                    stu.setText("输入账户或密码不能为空");
                    return;
                }
                try {
                    sent("clear");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent("1");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent(name);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent(password);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent("end");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }//即监听(实时)

        });
        jb1.addActionListener(new ActionListener() {//注册
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = tf2.getText();
                String password = tf.getText();
                try {
                    client();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                new Thread(new Receive()).start();
                if(name==null || password==null){
                    stu.setText("输入账户或密码不能为空");
                    return;
                }
                try {
                    sent("clear");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent("2");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent(name);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent(password);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                try {
                    sent("end");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

            }//即监听(实时)

        });

    }

    void way1() {
        f.setBounds(400, 200, 500, 400);// 坐标、尺寸
        // Default(默认)，Operation(操作)
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// 点×即关闭
    }
    public static void main(String[] args) throws IOException {
        cen d = new cen();
        d.way1();// 窗体基本属性
        d.way2();// 容器。复选框。

        d.f.setVisible(true);// 窗体可见
    }


    public void sent(String str) throws IOException {//发送消息
        os = new DataOutputStream(socket.getOutputStream());
        os.writeUTF(str);
    }

    public static void client() throws IOException {//客户端
         InetAddress inet =  InetAddress.getLocalHost();
        socket = new Socket(inet, 8899);
      boolean m=socket.isConnected();
      System.out.println(m);
    }

    class Receive implements Runnable {

        @Override
        public void run() {
            try {
                while (true) {
                    DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
                    String str = dataInputStream.readUTF();
                    //通讯消息
                    stu.setText(str);//1登录成功,2账号或密码有误,3注册成功,4重复注册
                    if(str.equals("登录成功")){
                     Main m=new  Main(9,9,10,tf2.getText());
                     Main.Count cd = new Main.Count();
                     cd.start();
                     f.dispose();
                    }
                    else if(str.equals("账号或密码有误")){
                        socket.close();
                    }
                    else if(str.equals("注册成功")){
                        socket.close();
                    }
                    else if(str.equals("重复注册")){
                        socket.close();
                    }
                }

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
class Main{
    static private int time = 0,mineNum = 0;/* 倒计时时间以及可用旗子数 */
    private static ImageIcon face = new ImageIcon("face.jpg");/* 小黄脸图标 */
    static private JLabel label1,label2;/* 提示文字 */
    static private Game gp;/* 雷区 */
    JMenuBar menuBar = new JMenuBar();
    JMenu mode = new JMenu("模式");
    JMenuItem mode1 = new JMenuItem("基础");
    JMenuItem mode2 = new JMenuItem("中级");
    JMenuItem mode3 = new JMenuItem("专家");
    JMenuItem mode4 = new JMenuItem("自定义");
    JMenuItem mode5 = new JMenuItem("退出");
    JFrame f;
    static String name;
    Main(int i,int j,int k,String name1) throws IOException {
        name=name1;
        /* 绘制窗口 */
        JFrame f = new JFrame("扫雷");
        f.setBounds(600,300,100+i*20,160+j*20);
        f.setDefaultCloseOperation(3);
        f.setLayout(null);
        f.setResizable(false);
        label1 = new JLabel("用时："+(time / 60 / 60 % 60) + ":"+ (time / 60 % 60)+ ":" +(time % 60));
        label1.setBounds(10,20,120,20);
        f.add(label1);
        /* 显示旗子数 */
        label2 = new JLabel("剩余:"+mineNum);
        label2.setBounds(20+i*20,20,120,20);
        f.add(label2);

        //添加模式选择
        menuBar.add(mode);
        mode.add(mode1);
        mode.add(mode2);
        mode.add(mode3);
        mode.add(mode4);
        mode.add(mode5);
        f.setJMenuBar(menuBar);

        mode1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                f.dispose();
                time = 0;
                try {
                    new Main(9,9,10,name);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        mode2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                f.dispose();
                time = 0;
                try {
                    new Main(16,16,40,name);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        mode3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                f.dispose();
                time = 0;
                try {
                    new Main(30,16,99,name);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        mode4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                question temp=new question(i,j,k);
                f.dispose();
            }
        });
        mode5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                f.dispose();
            }
        });

        /* 重置按钮 */
        JButton bt = new JButton(face);
        bt.setBounds(25+i*10,15,30,30);
        bt.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                f.dispose();
                time = 0;
                try {
                    new Main(i,j,k,name);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        f.add(bt);
        /* 绘制雷区 */
        gp = new Game(j,i,k,name);
        gp.setBounds(40,60,i*20,j*20);
        f.add(gp);


        /* 显示界面 */
        f.setVisible(true);
    }

    static class question{
        private JTextField rows,cols,num;
        private JLabel Rows,Cols,Num;
        private JButton ok,cancel;
        public question(int i,int j,int k){
            JFrame f = new JFrame("自定义");
            f.setTitle("自定义");
            f.setDefaultCloseOperation(2);
            f.setBounds(600,300,400,70);
            f.setLayout(new GridLayout(1,8,5,5));
            f.setResizable(false);
            Rows=new JLabel("行数");
            Cols=new JLabel("列数");
            Num=new JLabel("炸弹数");
            ok=new JButton("确定");
            ok.setMargin(new Insets(0,0,0,0));
            cancel=new JButton("取消");
            cancel.setMargin(new Insets(0,0,0,0));
            rows=new JTextField();
            cols=new JTextField();
            num=new JTextField();
            f.add(Rows);
            f.add(rows);
            f.add(Cols);
            f.add(cols);
            f.add(Num);
            f.add(num);
            f.add(ok);
            f.add(cancel);
            f.setVisible(true);
            ok.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e) {
                    String R=rows.getText();
                    String C=cols.getText();
                    String N=num.getText();
                    if(R.equals("")||C.equals("")||N.equals("")) {
                        JOptionPane.showMessageDialog(null,"请输入完整信息","错误操作",JOptionPane.PLAIN_MESSAGE);
                    }
                    else {
                        int r=Integer.valueOf(R);
                        int c=Integer.valueOf(C);
                        int n=Integer.valueOf(N);
                        if(n>r*c) {
                            JOptionPane.showMessageDialog(null,"炸弹过多","错误操作",JOptionPane.PLAIN_MESSAGE);
                        }
                        else {
                            f.dispose();
                            time = 0;
                            try {
                                new Main(c,r,n,name);
                            } catch (IOException ex) {
                                throw new RuntimeException(ex);
                            }
                        }
                    }
                }
            });
            cancel.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e) {
                    time = 0;
                    try {
                        new Main(i,j,k,name);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            });


        }

    }





    /* 计时线程 */
    static class Count extends Thread{
        public void run(){
            while (true){
                try{
                    time++;
                    File file = new File(name+"path.txt");//文件可以不存在,自动创建
                    FileWriter fr=new FileWriter(file,false);//true为添加,flase为附加(不自带换行)
                    fr.write(time+"\n");


                    if(time / 60 % 60 < 10&&time % 60 < 10) {
                        label1.setText("用时："+(time / 60 / 60 % 60) + ":0"+ (time / 60 % 60)+ ":0" +(time % 60));
                        fr.write("用时："+(time / 60 / 60 % 60) + ":0"+ (time / 60 % 60)+ ":0" +(time % 60));
                    }
                    else if(time / 60 % 60 >= 10&&time % 60 < 10) {
                        label1.setText("用时："+(time / 60 / 60 % 60) + ":"+ (time / 60 % 60)+ ":0" +(time % 60));
                        fr.write("用时："+(time / 60 / 60 % 60) + ":"+ (time / 60 % 60)+ ":0" +(time % 60));
                    }
                    else if(time / 60 % 60 < 10&&time % 60 >= 10) {
                        label1.setText("用时："+(time / 60 / 60 % 60) + ":0"+ (time / 60 % 60)+ ":" +(time % 60));
                        fr.write("用时："+(time / 60 / 60 % 60) + ":0"+ (time / 60 % 60)+ ":" +(time % 60));
                    }
                    else {
                        label1.setText("用时："+(time / 60 / 60 % 60) + ":"+ (time / 60 % 60)+ ":" +(time % 60));
                        fr.write("用时："+(time / 60 / 60 % 60) + ":"+ (time / 60 % 60)+ ":" +(time % 60));
                    }
                    fr.close();
                    this.sleep(1000);
                }catch (Exception e){
                    System.out.println("错误：" + e.toString());
                }
            }
        }

    }




    /* 修改旗子数 */
    public static void setMineNum(int i){
        mineNum = i;
        label2.setText("剩余:"+mineNum);
    }
}


class Game extends JPanel {
    private int rows, cols, bombCount,flagNum;
    private final int BLOCKWIDTH = 20;
    private final int BLOCKHEIGHT = 20;
    private JLabel[][] label;
    private boolean[][] state;
    private Btn[][] btns;
    private byte[][] click;
    private static ImageIcon flag = new ImageIcon("flag.jpg");
    private static ImageIcon bomb = new ImageIcon("bomb.jpg");
    private static ImageIcon no;
    Socket socket;
    DataOutputStream os;
    /* 构造雷区 */
    public Game(int row, int col, int num,String name) {
        rows = row;/* 行数 */
        cols = col;/* 列数 */
        bombCount = num; /* 地雷数 */
        flagNum = bombCount;/* 标记数（用于插旗） */
        label = new JLabel[rows][cols];
        state = new boolean[rows][cols];/* 用于存储是否有地雷 */
        btns = new Btn[rows][cols];
        click = new byte[rows][cols];/* 用于存储按钮点击状态（0-未点击，1-已点击，2-未点击但周围有雷，3-插旗） */
        Main.setMineNum(flagNum);
        setLayout(null);
        initLable();
        randomBomb();
        writeNumber();
        randomBtn(name);
    }

    public void initLable() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                JLabel l = new JLabel("", JLabel.CENTER);
                // 设置每个小方格的边界
                l.setBounds(j * BLOCKWIDTH, i * BLOCKHEIGHT, BLOCKWIDTH, BLOCKHEIGHT);
                // 绘制方格边框
                l.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                // 设置方格为透明,便于我们填充颜色
                l.setOpaque(true);
                // 背景填充为灰色
                l.setBackground(Color.lightGray);
                // 将方格加入到容器中(即面板JPanel)
                this.add(l);
                // 将方格存到类变量中,方便公用
                label[i][j] = l;
                label[i][j].setVisible(false);
            }
        }
    }

    /* 绘制地雷 */
    private void randomBomb() {
        for (int i = 0; i < bombCount; i++) {
            int rRow = (int) (Math.random() * rows);
            int rCol = (int) (Math.random() * cols);
            if(state[rRow][rCol] == false) {
                if(rRow==0&&rCol==0) {

                }
                label[rRow][rCol].setIcon(bomb);
                state[rRow][rCol] = true;/* 有地雷的格子state为真 */
            }
            else {
                i--;
            }
        }
    }

    /* 绘制数字 */
    private void writeNumber() {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                if (state[i][j]) {
                    continue;
                }
                int bombCount = 0;
                /* 寻找以自己为中心的九个格子中的地雷数 */
                for (int r = -1; (r + i < rows) && (r < 2); ++r) {
                    if (r + i < 0) continue;
                    for (int c = -1; (c + j < cols) && (c < 2); ++c) {
                        if (c + j < 0) continue;
                        if (state[r + i][c + j]) ++bombCount;
                    }
                }
                if (bombCount > 0) {
                    click[i][j] = 2;
                    label[i][j].setText(String.valueOf(bombCount));
                }
            }
        }
    }

    /* 绘制按钮 */
    private void randomBtn(String name) {
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                Btn btn = new Btn();
                btn.i = i;
                btn.j = j;
                btn.setBounds(j * BLOCKWIDTH, i * BLOCKHEIGHT, BLOCKWIDTH, BLOCKHEIGHT);
                this.add(btn);
                btns[i][j] = btn;
                btn.addMouseListener(new MouseAdapter() {
                                         public void mouseClicked(MouseEvent e) {
                                             /* 左键点击 */
                                             if(e.getButton() == MouseEvent.BUTTON1) open(btn);
                                             /* 右键点击 */
                                             if(e.getButton() == MouseEvent.BUTTON3) {
                                                 try {
                                                     placeFlag(btn,name);
                                                 } catch (IOException ex) {
                                                     throw new RuntimeException(ex);
                                                 }
                                             }
                                         }

                                     }
                );

            }
        }
    }

    /* 打开这个雷区 */
    private void open(Btn b){
        /* 踩雷 */
        if(state[b.i][b.j]){
            for (int r = 0;r < rows;++r){
                for(int c = 0;c < cols; ++c){
                    btns[r][c].setVisible(false);/* 隐藏label */
                    label[r][c].setVisible(true);/* 显示按钮（这里只有隐藏了按钮才能显示按钮下面的label） */
                }
            }
            JOptionPane.showMessageDialog(null,"您失败了","游戏结束",JOptionPane.PLAIN_MESSAGE);
        }else /* 没有踩雷 */{
            subopen(b);
        }
    }
    /* 递归打开周边雷区 */
    private void subopen(Btn b){
        /* 有雷，不能打开 */
        if(state[b.i][b.j]) return;
        /* 打开过的和插旗的，不用打开 */
        if(click[b.i][b.j] == 1 || click[b.i][b.j] == 3) return;
        /* 周围有雷的，只打开它 */
        if(click[b.i][b.j] == 2) {
            b.setVisible(false);
            label[b.i][b.j].setVisible(true);
            click[b.i][b.j] = 1;
            return;
        }
        /* 打开当前这个按钮 */
        b.setVisible(false);
        label[b.i][b.j].setVisible(true);
        click[b.i][b.j] = 1;
        /* 递归检测周边八个按钮 */
        for (int r = -1; (r + b.i < rows) && (r < 2); ++r) {
            if (r + b.i < 0) continue;
            for (int c = -1; (c + b.j < cols) && (c < 2); ++c) {
                if (c + b.j < 0) continue;
                if (r==0 && c==0) continue;
                Btn newbtn = btns[r + b.i][c + b.j];
                subopen(newbtn);
            }
        }
    }
    /* 插旗 */
    private void placeFlag(Btn b,String name) throws IOException {
        /* 只能插和地雷数相同数目的旗子 */
        if(flagNum>0){
            /* 插过旗的，再点一次取消 */
            if(click[b.i][b.j] == 3){
                b.setIcon(no);
                if(label[b.i][b.j].getText() == "[0-9]") click[b.i][b.j] = 2;
                else click[b.i][b.j] = 0;
                ++ flagNum;
                Main.setMineNum(flagNum);
            }else /* 未插旗的，插旗 */{
                b.setIcon(flag);
                click[b.i][b.j] = 3;
                -- flagNum;
                Main.setMineNum(flagNum);
            }
            /* 把所有旗子插完了，检测是否成功 */
            if(flagNum == 0){
                boolean flagstate = true;
                for(int i = 0;i < rows; ++i){
                    for(int j = 0;j < cols; ++j){
                        if (click[i][j] != 3 && state[i][j]) flagstate = false;
                    }
                }
                if(flagstate){
                    InetAddress inet =  InetAddress.getLocalHost();
                    socket = new Socket(inet, 8899);
                    sent("3");
                    sent(name);
                    String filePath = name+"path.txt";
                    File myFile = new File(filePath);
                    //文件路径
                    //fr.write("\r\n");
                    InputStreamReader Reader = new InputStreamReader(new FileInputStream(myFile), "UTF-8");
                    //考虑到编码格式，new FileInputStream(myFile)文件字节输入流，以字节为单位对文件中的数据进行读取
                    //new InputStreamReader(FileInputStream a, "编码类型")
                    //将文件字节输入流转换为文件字符输入流并给定编码格式

                    BufferedReader bufferedReader = new BufferedReader(Reader);
                    //BufferedReader从字符输入流中读取文本，缓冲各个字符，从而实现字符、数组和行的高效读取。
                    //通过BuffereReader包装实现高效读取

                    String lineTxt = null;

                    while ((lineTxt = bufferedReader.readLine()) != null) {
                        //buffereReader.readLine()按行读取写成字符串
                       sent(lineTxt);

                    }
                    sent("end");
                    JOptionPane.showMessageDialog(null,"您成功了","游戏结束",JOptionPane.PLAIN_MESSAGE);

                }
            }
        }
        else if(flagNum==0&&click[b.i][b.j] == 3){
            b.setIcon(no);
            if(label[b.i][b.j].getText() == "[0-9]") click[b.i][b.j] = 2;
            else click[b.i][b.j] = 0;
            ++ flagNum;
            Main.setMineNum(flagNum);
        }
        else {
            JOptionPane.showMessageDialog(null,"标记已用尽","错误操作",JOptionPane.PLAIN_MESSAGE);
        }
    }
    public void sent(String str) throws IOException {//发送消息
        os = new DataOutputStream(socket.getOutputStream());
        os.writeUTF(str);
    }
    /* 显示雷区 */
    public void showBomb(){
        for (int r = 0;r < rows;++r){
            for(int c = 0;c < cols; ++c){
                btns[r][c].setVisible(false);/* 隐藏label */
                label[r][c].setVisible(true);/* 显示按钮（这里只有隐藏了按钮才能显示按钮下面的label） */
            }
        }
    }
}

class Btn extends JButton{
    public int i,j;
}