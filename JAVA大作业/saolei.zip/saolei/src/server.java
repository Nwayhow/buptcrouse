

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class server {
    JFrame f=new JFrame();// 创建窗体
    Container c;// 容器
    static JTextArea ta;
    static JTextArea tb;
    DataOutputStream os;
    ArrayList<Clientcon> cclist=new ArrayList<>();
    ArrayList<Person> list ;
    ServerSocket ss;
    class Person implements Comparable<Person> {
        private String id;
        private int time;
        private String time1;

        public Person(String id, int time, String time1) {
            this.id = id;
            this.time = time;
            this.time1 = time1;
        }
        int getTime(){
            return time;
        }
        @Override
        public int compareTo(Person p) {
            return  this.getTime()-p.getTime();
        }
    }
    public void way2() throws IOException {
        // Content(包含)，pane（窗格）
        c=f.getContentPane();// 容器c嵌入窗体f中
        c.setLayout(new FlowLayout());// 布局，流布局，flow（流动）
        f.setTitle("服务器");
        f.setBounds(600, 150, 400, 600);
        f.setLocationRelativeTo(null);
        ta = new JTextArea(13, 40);
        ta.setEditable(false);
        tb = new JTextArea(13, 40);
        tb.setEditable(false);
        JLabel rate=new JLabel();
        JLabel account=new JLabel();
        rate.setText("排名");
        JScrollPane p=new JScrollPane(ta);
        account.setText("登录用户");
        JScrollPane q=new JScrollPane(tb);

        c.add(rate);
        c.add(p, BorderLayout.CENTER);
        c.add(account);
        c.add(q, BorderLayout.CENTER);

        f.setResizable(false);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ratestart();
        server();



    }
    void way1(){
        f.setBounds(400,200,500,400);// 坐标、尺寸
        // Default(默认)，Operation(操作)
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// 点×即关闭

    }
    public static void main(String[] args) throws IOException {
        server d=new server();
        d.way1();// 窗体基本属性
        d.way2();// 容器。复选框。

        d.f.setVisible(true);// 窗体可见
    }

    class Clientcon implements Runnable{
        Socket s=null;
        String mes[]=new String[100];
        String name="0";
        int cons=0;
        public  Clientcon(Socket s){
            this.s=s;
            (new Thread(this)).start();
        }

        @Override
        public void run() {
            try {
                DataInputStream is = new DataInputStream(s.getInputStream());
                while(true) {
                    String str = is.readUTF();
                    mes[cons]=str;
                    cons++;
                    if(str.equals("end")){
                        cons=0;
                        if(Objects.equals(mes[0], "1")){//登录
                            String filePath = "account.txt";
                            File myFile = new File(filePath);
                            //文件路径
                            //fr.write("\r\n");
                            InputStreamReader Reader = new InputStreamReader(new FileInputStream(myFile), "UTF-8");
                            //考虑到编码格式，new FileInputStream(myFile)文件字节输入流，以字节为单位对文件中的数据进行读取
                            //new InputStreamReader(FileInputStream a, "编码类型")
                            //将文件字节输入流转换为文件字符输入流并给定编码格式

                            BufferedReader bufferedReader = new BufferedReader(Reader);
                            //BufferedReader从字符输入流中读取文本，缓冲各个字符，从而实现字符、数组和行的高效读取。
                            //通过BuffereReader包装实现高效读取

                            String lineTxt = null;

                            while ((lineTxt = bufferedReader.readLine()) != null) {
                                if(lineTxt.equals(mes[1])){
                                    lineTxt = bufferedReader.readLine();
                                    if(lineTxt.equals(mes[2])){
                                        sent("登录成功");
                                        Date day=new Date();
                                        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                        tb.append("账号"+mes[1]+"登录成功:"+"\n登录ip为:"+s.getInetAddress()+"\n登录时间为:"+df.format(day)+"\n");
                                        return;
                                    }
                                }
                                lineTxt = bufferedReader.readLine();
                            }

                            Reader.close();
                            sent("账号或密码有误");return;


                        }
                        else if(Objects.equals(mes[0], "2")){//注册
                            String filePath = "account.txt";
                            File myFile = new File(filePath);
                            //文件路径
                            //fr.write("\r\n");
                            InputStreamReader Reader = new InputStreamReader(new FileInputStream(myFile), "UTF-8");
                            //考虑到编码格式，new FileInputStream(myFile)文件字节输入流，以字节为单位对文件中的数据进行读取
                            //new InputStreamReader(FileInputStream a, "编码类型")
                            //将文件字节输入流转换为文件字符输入流并给定编码格式

                            BufferedReader bufferedReader = new BufferedReader(Reader);
                            //BufferedReader从字符输入流中读取文本，缓冲各个字符，从而实现字符、数组和行的高效读取。
                            //通过BuffereReader包装实现高效读取

                            String lineTxt = null;
                            while ((lineTxt = bufferedReader.readLine()) != null) {
                                if(lineTxt.equals(mes[1])){
                                        sent("重复注册");
                                        return;
                                }
                                lineTxt = bufferedReader.readLine();

                            }
                            Reader.close();
                            File file = new File("account.txt");//文件可以不存在,自动创建
                            FileWriter fr=new FileWriter(file,true);//true为添加,flase为附加(不自带换行)
                            fr.write(mes[1]+"\n");
                            fr.write(mes[2]+"\n");
                            fr.close();
                            sent("注册成功");return;
                        }
                        else if(Objects.equals(mes[0], "3")){//完成任务
                            for(Person p : list){
                                if(p.id.equals(mes[1])){
                                    if(p.time>Integer.parseInt(mes[2])){
                                        p.time1=mes[3];
                                        p.time=Integer.parseInt(mes[2]);

                                        try {
                                            re();
                                        } catch (IOException e) {
                                            throw new RuntimeException(e);
                                        }
                                        try {
                                            ratestart();
                                        } catch (IOException e) {
                                            throw new RuntimeException(e);
                                        }
                                        return;

                                    }
                                    else return;
                                }

                            }

                            list.add(new Person(mes[1],Integer.parseInt(mes[2]),mes[3]));
                            re();
                            ratestart();
                        }


                    }
                    else if(str.equals("clear")){
                        cons=0;
                    }



                    //Iterator<Clientcon> it=cclist.iterator();
                    //while(it.hasNext()){
                    //    Clientcon o=it.next();//姓名一致 if(it.next().name==o.name it.remove
                   //     o.sent(s1);
                   // }

                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        public void sent(String str) throws IOException {
            os =new DataOutputStream(this.s.getOutputStream());
            os.writeUTF(str);


        }
    }
    public void ratestart() throws IOException {
        String filePath = "rate.txt";
        File myFile = new File(filePath);
        //文件路径
        //fr.write("\r\n");
        InputStreamReader Reader = new InputStreamReader(new FileInputStream(myFile), "UTF-8");
        //考虑到编码格式，new FileInputStream(myFile)文件字节输入流，以字节为单位对文件中的数据进行读取
        //new InputStreamReader(FileInputStream a, "编码类型")
        //将文件字节输入流转换为文件字符输入流并给定编码格式

        BufferedReader bufferedReader = new BufferedReader(Reader);
        //BufferedReader从字符输入流中读取文本，缓冲各个字符，从而实现字符、数组和行的高效读取。
        //通过BuffereReader包装实现高效读取

        String lineTxt = null;
        String lineTxt1 = null;
        String lineTxt2 = null;
        list = new ArrayList<Person>();
        while ((lineTxt = bufferedReader.readLine()) != null) {
            lineTxt1 = bufferedReader.readLine();
            lineTxt2 = bufferedReader.readLine();
            list.add(new Person(lineTxt, Integer.parseInt(lineTxt1) ,lineTxt2));
        }
        Collections.sort(list);
        int r=0;
        ta.setText("排行榜为:\n");
        for(Person str : list){
            r++;//同for(int i = 0;i<list.size();i++)
            ta.append("排名第"+r+"的用户id为:"+str.id);
            ta.append(" "+str.time1+"\n");

        }


    }
    public void re() throws IOException {
        File file = new File("rate.txt");//文件可以不存在,自动创建
        FileWriter fr=new FileWriter(file,false);//true为添加,flase为附加(不自带换行)
        for(Person p : list){

                fr.write(p.id+"\n");
                fr.write(p.time+"\n");
                fr.write(p.time1+"\n");

        }

        fr.close();
    }
    public void server() throws IOException {
        ss=new ServerSocket(8899);
        while(true) {
            Socket socket = ss.accept();
            cclist.add(new Clientcon(socket));

        }
    }
}
